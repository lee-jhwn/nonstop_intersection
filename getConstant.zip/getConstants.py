######################################
# getConstants.py
#
#
# This script is used to get constants used for the MIP formulation.
# Given the structure of the intersection, it computes all machines & relevant constants.
######################################

import numpy as np
import math
import sys
import xml.etree.ElementTree as ET
from argparse import ArgumentParser
from icecream import ic
from matplotlib import pyplot as plt
from matplotlib.patches import Rectangle
from scipy.ndimage.measurements import label
from scipy import special
from scipy.optimize import fsolve

##################
# Helper Functions
##################

# Converts km/hr to m/s
def kmhr2ms( veh_spd ):
    return veh_spd*(1/3.6)

# Draw a figure of the int_array
def draw_int( int_array , save = False, title = None ):
    # if save == True:
    #     plt.figure(figsize=(8,8))
    #     currentAxis = plt.gca()

    #     # Loop through the int_array
    #     it = np.nditer(int_array, flags=['multi_index'])
    #     while not it.finished:
    #         # print(it.multi_index)
    #         # Draw rectangle using the value
    #         currentAxis.add_patch( Rectangle((it.multi_index[1],it.multi_index[0]), 1, 1, facecolor = (0,0,1,0.1*it[0]), linewidth=0.1,edgecolor='k') )
    #         it.iternext()

    #     # Set Axis & Ticks
    #     currentAxis.set_xlim([0,int_array.shape[1]])
    #     currentAxis.set_ylim([0,int_array.shape[0]])
    #     plt.xticks(np.arange(0,int_dict['int_w']*options.ppm,step=int_dict['lane_w']*options.ppm))
    #     plt.yticks(np.arange(0,int_dict['int_h']*options.ppm,step=int_dict['lane_w']*options.ppm))

    #     # Save file
    #     plt.savefig('file.png')

    # Heatmap
    # plt.imshow( int_array, cmap = 'hot', interpolation='nearest')
    plt.figure()
    currAxe = plt.gca()
    plt.imshow( int_array, cmap = 'Blues', interpolation='None', vmin = 0 )
    # plt.imshow( int_array, interpolation='None', vmin = 0 )

    # FIX ME: With heatmaps, there might be interpolation issue. Currently we are offsetting the axis by 0.5
    plt.xticks(np.arange(0.5,int_dict['int_w']*options.ppm,step=1))
    plt.yticks(np.arange(0.5,int_dict['int_h']*options.ppm,step=1))
    currAxe.axes.xaxis.set_ticklabels([])
    currAxe.axes.yaxis.set_ticklabels([])
    currAxe.set_title(title)
    plt.colorbar()
    plt.grid(linewidth=0.1)
    if save == True:
        plt.savefig(title.replace(' ','_') + '.png', dpi=600)
    return

# Input
#   len_x : 'radius' of ellipse in x-axis
#   len_y : 'radius' of ellipse in y-axis
# Output
#   out : list of tuple of indices
#   x : x-value of the ellipse
#   y : y-value of the ellipse
#   Values are scaled via ppm. Integerized value of (x,y) represent the index at the int_array
# Parameters
#   delta_t : discretization step
def getLeftIndex(len_x=1, len_y=1):
    delta_t = options.sampling_time

    # for each angle, get (x,y) position of ellipse 
    t = np.arange(start = 1.5*math.pi + 0.001, stop = 2.0*math.pi, step = delta_t)
    # t = np.arange(start = 0, stop = math.pi*0.5, step = delta_t)

    # We transform this to match the structure of the int_array
    # x = np.maximum( len_x*np.cos( t ), 0 )
    # y = np.maximum( len_y*np.sin( t ) + int_dict['int_h'], 0 )
    x = len_x*np.cos( t )
    y = len_y*np.sin( t ) + int_dict['int_h'] * options.ppm

    ic(x,y)
    # interize and make it into list of tuple
    return np.floor(x).astype(int), np.floor(y).astype(int)

    # We interize x,y to get actual index of array
    # return x, y

def getRightIndex(len_x=1, len_y=1):
    delta_t = options.sampling_time

    # for each angle, get (x,y) position of ellipse 
    t = np.arange(start = 1.0*math.pi + 0.001, stop = 1.5*math.pi, step = delta_t)
    # t = np.arange(start = 0, stop = math.pi*0.5, step = delta_t)

    # We transform this to match the structure of the int_array
    # x = np.maximum( len_x*np.cos( t ), 0 )
    # y = np.maximum( len_y*np.sin( t ) + int_dict['int_h'], 0 )
    x = len_x*np.cos( t ) + int_dict['int_w'] * options.ppm
    y = len_y*np.sin( t ) + int_dict['int_h'] * options.ppm

    ic('getRightIndex:',x,y)
    # interize and make it into list of tuple
    return np.floor(x).astype(int), np.floor(y).astype(int)



# This function returns array in same size as int_aray with straight colored
# Input
#   rotation(array) : each element denotes the 90 degree rotation we add for the return value
# Output
#   temp_array(2d array) : intersection grid with straight colored
def colorStraight( rotation = [0,1,2,3] ):
    temp_array = np.zeros(( int_dict['int_h']*options.ppm, int_dict['int_w']*options.ppm ) )

    for lane_cnt in range(0, int_dict['lane_cnt_w_o']):
        # Variables
        # left most position of the lane in meters
        lane_start_pos = int_dict['lane_cnt_w_i'] * int_dict['lane_w'] + lane_cnt * int_dict['lane_w']

        # Straight
        dest = 1
        if allowed_dest[0][lane_cnt][dest] == 0:
            # Not allowed
            continue

        # Go straight
        path_x_start_pos = lane_start_pos + 0.5 * ( int_dict['lane_w'] ) - 0.5*veh_dict['width']
        path_x_end_pos   = lane_start_pos + 0.5 * ( int_dict['lane_w'] ) + 0.5*veh_dict['width']
        path_x_start_cnt = math.floor(path_x_start_pos * options.ppm)
        path_x_end_cnt   = math.ceil(path_x_end_pos * options.ppm)

        ic(path_x_start_pos, path_x_end_pos)
        temp_array[:,path_x_start_cnt:path_x_end_cnt] += 1      # Note: we are shotening by 1 pixel at the end (using end_cnt instead of end_cnt+1)

    out = np.zeros(( int_dict['int_h']*options.ppm, int_dict['int_w']*options.ppm ) )
    for rot in rotation:
        out = out + np.rot90( temp_array,rot)

    return out

def colorLeft( rotation = [0,1,2,3] ):
    out = np.zeros(( int_dict['int_h']*options.ppm, int_dict['int_w']*options.ppm ) )
    for lane_cnt in range(0, int_dict['lane_cnt_w_o']):
        # Variables
        # left most position of the lane in meters
        lane_start_pos = int_dict['lane_cnt_w_i'] * int_dict['lane_w'] + lane_cnt * int_dict['lane_w']

        if allowed_dest[0][lane_cnt][0] == 0:
            # Not allowed
            continue

        # Basic distance to destination lane
        lane_dest_pos = int_dict['lane_cnt_h_o'] * int_dict['lane_w'] + lane_cnt * int_dict['lane_w']

        # minor/major for inner/outer ellipse 
        inner_x_pos = lane_start_pos + 0.5 * ( int_dict['lane_w'] ) - 0.5*veh_dict['width']
        outer_x_pos = lane_start_pos + 0.5 * ( int_dict['lane_w'] ) + 0.5*veh_dict['width']

        inner_y_pos = lane_dest_pos + 0.5 * ( int_dict['lane_w'] ) - 0.5*veh_dict['width']
        outer_y_pos = lane_dest_pos + 0.5 * ( int_dict['lane_w'] ) + 0.5*veh_dict['width']

        ic(lane_start_pos, inner_x_pos, outer_x_pos, inner_y_pos, outer_y_pos)

        # Temp array for a single path
        temp_array = np.zeros(( int_dict['int_h']*options.ppm, int_dict['int_w']*options.ppm ) )

        # Inner ellipse
        x_idx, y_idx = getLeftIndex(len_x = inner_x_pos * options.ppm, len_y = inner_y_pos * options.ppm  )
        # ic(x_idx,y_idx)
        temp_array[y_idx,x_idx] += 1

        # Outer ellipse
        x_idx, y_idx = getLeftIndex(len_x = outer_x_pos * options.ppm, len_y = outer_y_pos * options.ppm  )
        temp_array[y_idx,x_idx] += 1

        # Fill in
        # print(temp_array)
        # print( np.nonzero(temp_array) )
        row_arr = np.nonzero( temp_array )[0]           # this is index of row with non zero elements
        col_arr = np.nonzero( temp_array )[1]           # this is index of column with nonzero elements

        for k in range(0,np.shape( temp_array )[1]):
            # print( row_arr[np.where( col_arr == k )] )

            # In column list, we find index of k-th column. This returns indices of nonzero elements
            # Next, use found indices to find the corresponding index of row
            # Finally, take min & max to find the two ends we want to fill
            result_arr = row_arr[np.where( col_arr == k )]

            # ic(result_arr)
            # Array empty, do nothing
            if result_arr.size == 0:
                continue

            # Get values
            min_val = np.min( result_arr )
            max_val = np.max( result_arr )

            # in this case, set max to end
            # ic(inner_x_pos * options.ppm )
            if k >= np.floor(inner_x_pos * options.ppm):
                # ic(k, temp_array.shape[1] )
                max_val = temp_array.shape[1]

            temp_array[min_val:max_val,k] = 1

        out = out + temp_array

    result = np.zeros(( int_dict['int_h']*options.ppm, int_dict['int_w']*options.ppm ) )
    # Rotate
    for rot in rotation:
        result = result + np.rot90(out,rot)

    return result


def colorRight( rotation = [0,1,2,3] ):
    out = np.zeros(( int_dict['int_h']*options.ppm, int_dict['int_w']*options.ppm ) )
    for lane_cnt in range(0, int_dict['lane_cnt_w_o']):
        # Variables
        # left most position of the lane in meters
        lane_start_pos = int_dict['lane_cnt_w_i'] * int_dict['lane_w'] + lane_cnt * int_dict['lane_w']

        if allowed_dest[0][lane_cnt][2] == 0:
            # Not allowed
            continue

        # Basic distance to destination lane 
        lane_dest_pos = int_dict['lane_cnt_h_o'] * int_dict['lane_w'] + lane_cnt * int_dict['lane_w']

        # minor/major for inner/outer ellipse 
        inner_x_pos = int_dict['int_w'] - (lane_start_pos + 0.5 * ( int_dict['lane_w'] ) + 0.5*veh_dict['width'])
        outer_x_pos = int_dict['int_w'] - (lane_start_pos + 0.5 * ( int_dict['lane_w'] ) - 0.5*veh_dict['width'])

        # currently only supports traveling to the same lane
        inner_y_pos = inner_x_pos
        outer_y_pos = outer_x_pos

        ic(lane_start_pos, inner_x_pos, outer_x_pos, inner_y_pos, outer_y_pos)

        # Temp array for a single path
        temp_array = np.zeros(( int_dict['int_h']*options.ppm, int_dict['int_w']*options.ppm ) )

        # Inner ellipse
        x_idx, y_idx = getRightIndex(len_x = inner_x_pos * options.ppm, len_y = inner_y_pos * options.ppm  )
        ic(x_idx,y_idx)
        temp_array[y_idx,x_idx] += 1

        # Outer ellipse
        x_idx, y_idx = getRightIndex(len_x = outer_x_pos * options.ppm, len_y = outer_y_pos * options.ppm  )
        temp_array[y_idx,x_idx] += 1

        # Fill in
        # print(temp_array)
        # print( np.nonzero(temp_array) )
        row_arr = np.nonzero( temp_array )[0]           # this is index of row with non zero elements
        col_arr = np.nonzero( temp_array )[1]           # this is index of column with nonzero elements

        for k in range(0,np.shape( temp_array )[1]):
            # print( row_arr[np.where( col_arr == k )] )

            # In column list, we find index of k-th column. This returns indices of nonzero elements
            # Next, use found indices to find the corresponding index of row
            # Finally, take min & max to find the two ends we want to fill
            result_arr = row_arr[np.where( col_arr == k )]

            # ic(result_arr)
            # Array empty, do nothing
            if result_arr.size == 0:
                continue

            # Get values
            min_val = np.min( result_arr )
            max_val = np.max( result_arr )

            # in this case, set max to end
            # ic(inner_x_pos * options.ppm )
            if k <= np.floor( (int_dict['int_w'] - inner_x_pos) * options.ppm):
                # ic(k, temp_array.shape[1] )
                max_val = temp_array.shape[1]

            temp_array[min_val:max_val,k] = 1

        out = out + temp_array

    result = np.zeros(( int_dict['int_h']*options.ppm, int_dict['int_w']*options.ppm ) )
    # Rotate
    for rot in rotation:
        result = result + np.rot90(out,rot)

    return result

# Clean up. Remove the single lines at both ends for the curve
def cleanData( int_array, rotation = [0,1,2,3] ):
    # clean left turns
    for lane_cnt in range(0, int_dict['lane_cnt_w_o']):
        # left most position of the lane in meters
        lane_start_pos = int_dict['lane_cnt_w_i'] * int_dict['lane_w'] + lane_cnt * int_dict['lane_w']

        if allowed_dest[0][lane_cnt][0] == 0:
            # Not allowed
            continue

        # Basic distance to destination lane
        lane_dest_pos = int_dict['lane_cnt_h_o'] * int_dict['lane_w'] + lane_cnt * int_dict['lane_w']

        # minor/major for inner/outer ellipse 
        inner_x_pos = lane_start_pos + 0.5 * ( int_dict['lane_w'] ) - 0.5*veh_dict['width']
        outer_x_pos = lane_start_pos + 0.5 * ( int_dict['lane_w'] ) + 0.5*veh_dict['width']

        inner_y_pos = lane_dest_pos + 0.5 * ( int_dict['lane_w'] ) - 0.5*veh_dict['width']
        outer_y_pos = lane_dest_pos + 0.5 * ( int_dict['lane_w'] ) + 0.5*veh_dict['width']

        # Temp array for a single path
        temp_array = np.ones(( int_dict['int_h']*options.ppm, int_dict['int_w']*options.ppm ) )

        # Inner ellipse
        x_idx, y_idx = getLeftIndex(len_x = inner_x_pos * options.ppm, len_y = inner_y_pos * options.ppm  )
        # ic(x_idx,y_idx)
        temp_array[y_idx,x_idx] = 0

        # Outer ellipse
        x_idx, y_idx = getLeftIndex(len_x = outer_x_pos * options.ppm, len_y = outer_y_pos * options.ppm  )
        temp_array[y_idx,x_idx] = 0

        # Rotate
        for rot in rotation:
            int_array = np.multiply( int_array, np.rot90(temp_array,rot) )

    # clean right turns
    for lane_cnt in range(0, int_dict['lane_cnt_w_o']):
        # Variables
        # left most position of the lane in meters
        lane_start_pos = int_dict['lane_cnt_w_i'] * int_dict['lane_w'] + lane_cnt * int_dict['lane_w']

        if allowed_dest[0][lane_cnt][2] == 0:
            # Not allowed
            continue

        # Basic distance to destination lane 
        lane_dest_pos = int_dict['lane_cnt_h_o'] * int_dict['lane_w'] + lane_cnt * int_dict['lane_w']

        # minor/major for inner/outer ellipse 
        inner_x_pos = int_dict['int_w'] - (lane_start_pos + 0.5 * ( int_dict['lane_w'] ) + 0.5*veh_dict['width'])
        outer_x_pos = int_dict['int_w'] - (lane_start_pos + 0.5 * ( int_dict['lane_w'] ) - 0.5*veh_dict['width'])

        # currently only supports traveling to the same lane
        inner_y_pos = inner_x_pos
        outer_y_pos = outer_x_pos

        # Temp array for a single path
        temp_array = np.ones(( int_dict['int_h']*options.ppm, int_dict['int_w']*options.ppm ) )

        # Inner ellipse
        x_idx, y_idx = getRightIndex(len_x = inner_x_pos * options.ppm, len_y = inner_y_pos * options.ppm  )
        ic(x_idx,y_idx)
        temp_array[y_idx,x_idx] = 0

        # Outer ellipse
        x_idx, y_idx = getRightIndex(len_x = outer_x_pos * options.ppm, len_y = outer_y_pos * options.ppm  )
        temp_array[y_idx,x_idx] = 0

        # Rotate
        for rot in rotation:
            int_array = np.multiply( int_array, np.rot90(temp_array,rot) )

    return int_array

# From the intersection, on each pixel, compute how many vehicles may collide
def computeCollision():
    out_array = np.zeros(( int_dict['int_h']*options.ppm, int_dict['int_w']*options.ppm ) )

    # Get Straight
    mask_Straight = colorStraight()

    # Get Left
    mask_Left = colorLeft()

    # Get Right
    mask_Right = colorRight()

    out_array = mask_Straight + mask_Left + mask_Right
    # int_array = mask_Straight + mask_Left
    out_array = cleanData(out_array)

    return out_array

# from the collision matrix, label each machine
def labelMachine( int_array ):
    # Maximum number of collision
    collision_max = np.amax( int_array ).astype(int)

    # Data for number of machine for each collision
    label_count = np.zeros( collision_max + 1 )

    # Data for represetning the areas of machine. List of 2d array
    label_mtx   = []

    # Var used to store previous machine count for proper numbering
    prev_count  = 0

    out_array = np.zeros(( int_dict['int_h']*options.ppm, int_dict['int_w']*options.ppm ) )

    # Ignore k=0,1 since it is not needed
    for k in range(2,collision_max+1):  
        # Get labelling with collision = k    
        temp_label, temp_count = label( np.where(int_array == k, int_array, 0) )

        # Store result
        label_count[k] = temp_count
        label_mtx.append( temp_label )

        # Draw data
        # draw_int( temp_label, title = 'Collision Level ' + str(k) )

        # Update array with machine naming
        out_array = out_array + np.where( temp_label > 0, temp_label + prev_count, 0 )

        prev_count = temp_count

    # draw_int( out_array, title='Labelled Array')

    return label_mtx, out_array

# find machine for a single straight lane
def findMachineStraightLane( mac_array, idx_left, idx_right):
    # output
    max_machine = np.amax(mac_array)

    # Out_data (3,max_machine) array
    #
    # machine  #        x    
    # Stat idx          y 
    # end idx           z
    # delta(i,p)

    out_data  = np.zeros((4,int(max_machine)) )             # this contains machine, start index, end index, and time to go through each machine
    time_data = np.zeros((int(max_machine)+2,int(max_machine)+2) )           # this contains order of the machine as well as time. Represented as graph and stored as a 2D adjacency matrix. Index 0 : starting lane, Last index : ending lane

    arr_size = mac_array.shape[0]
    mach_counter = 0
    for k in range(0,arr_size):
        k_idx = arr_size - k - 1
        # result = np.multiply( mac_array[k_idx,idx_left:idx_right+1] , mask )
        result = mac_array[k_idx,idx_left:idx_right]

        # Get unique machine number excluding zero
        curr_machine = np.unique( result[np.nonzero(result)] )

        # Store data
        for mach in curr_machine:
            # already here, only update end
            if mach in out_data[0,:]:
                out_data[2,np.where(out_data[0,:] == mach) ] = k
                continue

            # newly seen machine, add to the list 
            out_data[0,mach_counter] = mach
            out_data[1,mach_counter] = k
            out_data[2,mach_counter] = k
            mach_counter += 1

    # Measure the time it takes to go through each machine
    for k, mach in enumerate(out_data[0,:]):
        # if actual machine and not plceholder
        if mach > 0:
            # pixels * (meters / pixel) * (seconds / meters)
            out_data[3,k] = ( out_data[2,k] - out_data[1,k] ) * (1/options.ppm) * (1/kmhr2ms(veh_dict['speed_s']))

            # Add vehicle length
            out_data[3,k] = out_data[3,k] + veh_dict['len'] * (1/kmhr2ms(veh_dict['speed_s']))


    # print(out_data)

    # Now, using the out_data, measure the time_data
    prev_machine_list = [ 0 ]
    prev_start   = 0
    k = 0
    while k < out_data[0,:].size:
        # curr machine & stating index
        mach = out_data[0,k]
        curr_start_idx = out_data[1,k]

        # if we reach end
        if mach == 0:
            total_len = mac_array.shape[0]-1
            for prev_machine in prev_machine_list:
                time_data[int(max_machine+1),int(prev_machine)] = ( total_len - prev_start) * (1/options.ppm) * (1/kmhr2ms(veh_dict['speed_s']))
                ic('Updating : ', int(max_machine+1), int(prev_machine), time_data[int(max_machine+1),int(prev_machine)] )
            break

        # find next machine. Note we might have multiple machines
        ic(prev_machine_list, prev_start)
        next_mach_list = []
        while out_data[1,k] == curr_start_idx:
            next_mach_list.append( out_data[0,k] )

            # Store data

            # time_data[a][b] means arrow from b to a
            # pixels * (meters / pixel) * (seconds / meters)
            for prev_machine in prev_machine_list:
                time_data[int( out_data[0,k] ),int(prev_machine)] = (out_data[1,k] - prev_start) * (1/options.ppm) * (1/kmhr2ms(veh_dict['speed_s']))
                ic('Updating : ', int(out_data[0,k]), int(prev_machine), time_data[int(out_data[0,k]),int(prev_machine)] )

            # increment 
            k = k+1 

        print("\n")
        # Update variables
        prev_machine_list = next_mach_list
        prev_start   = curr_start_idx

    print(time_data)
    return out_data, time_data

def equi_fun( x, *data ):
    # Parameters
    k, total_pts, C, x_len, y_len, e_sq = data


    # Integral finds the distance starting from the minor heading to major
    if x_len > y_len:
        # x-axis is major
        # return x_len*special.ellipeinc(x, e_sq) - ( C - (k/total_pts)*C )
        return x_len*special.ellipeinc(x, e_sq) - (k/total_pts) * C
    else:
        # y-axis is major
        return y_len*special.ellipeinc(x, e_sq) - (k/total_pts)*C
        # return y_len*special.ellipeinc(x, e_sq) - ( C - (k/total_pts)*C )

def findMachineLeftLane(mac_array, inner_x, outer_x, inner_y, outer_y):
    # Circumference/4
    inner_e_sq = 1 - min(inner_x,inner_y)**2/max(inner_x,inner_y)**2
    outer_e_sq = 1 - min(outer_x,outer_y)**2/max(outer_x,outer_y)**2
    inner_C = max(inner_x,inner_y)*special.ellipe(inner_e_sq)
    outer_C = max(outer_x,outer_y)*special.ellipe(outer_e_sq)

    # number of points along the circumference
    total_pts = options.turn_sample      # To do PARAMETER HERE

    in_x_list = []
    in_y_list = []
    out_x_list = []
    out_y_list = []

    # output
    max_machine = np.amax(mac_array)

    # Out_data (3,max_machine) array
    #
    # machine  #        x    
    # Stat idx          y 
    # end idx           z

    out_data = np.zeros((4,int(max_machine)) )
    time_data = np.zeros((int(max_machine)+2,int(max_machine)+2) )           # this contains order of the machine as well as time. Represented as graph and stored as a 2D adjacency matrix. Index 0 : starting lane, Last index : ending lane
    mach_counter = 0

    # for each point
    plt.figure()
    for q in range(0,total_pts+1):
        mask = np.zeros(( int_dict['int_h']*options.ppm, int_dict['int_w']*options.ppm ), dtype=int )

        # Parameters
        data = (q, total_pts, inner_C, inner_x, inner_y, inner_e_sq)

        # Find q-th point
        sol = fsolve( equi_fun, 0, args = data)
        in_x_list.append( inner_x*math.cos(sol) )
        in_y_list.append( inner_y*math.sin(sol) )

        # ic(sol, inner_x*math.cos(sol), inner_y * math.sin(sol))

        # Parameters
        data = (q, total_pts, outer_C, outer_x, outer_y, outer_e_sq)

        # Find q-th point
        sol = fsolve( equi_fun, 0, args = data)
        out_x_list.append( outer_x*math.cos(sol) )
        out_y_list.append( outer_y*math.sin(sol) )

        # ic(sol, outer_x*math.cos(sol), outer_y * math.sin(sol))

        # Find the equation of the line connecting two points. 
        # Equation is in form of 
        #   y = (y_2 - y_1) t + y_1, 
        #   x = (x_2 - x_1) t + x_1, 
        #   where t=0 to 1, results in point moving from inner ellipse to outer ellipse
        
        m_y = out_y_list[q] - in_y_list[q] 
        b_y = in_y_list[q]
        m_x = out_x_list[q] - in_x_list[q] 
        b_x = in_x_list[q]

        # x,y indices of the q-th line
        # TO DO: Parameter here
        line_delta = options.line_delta
        x_idx = np.floor( m_x * np.arange(0.01,0.99,line_delta) + b_x ).astype(int)
        y_idx = np.floor( m_y * np.arange(0.01,0.99,line_delta) + b_y ).astype(int) #+ int_dict['int_h'] * options.ppm - 1

        # ic(x_idx, y_idx)
        mask[y_idx,x_idx] = 1
        mask = np.flip(mask, axis= 0)
        # draw_int( mask )
        # mask = mask.transpose()
        # mask = np.rot90( mask, 1)
        # print('MASK')
        # print( mask )
        # print('MASK * ARRAY')
        # print( np.multiply(mask, mac_array ).astype(int) )
        # plt.imshow(mask)
        # plt.show()

        result = np.multiply( mac_array, mask )

        curr_machine = np.unique( result[np.nonzero(result)]  )

        # print(machine_list)

        # plt.scatter(np.floor(m_x*np.arange(0,1,0.01)+b_x) ,np.floor(m_y*np.arange(0,1,0.01)+b_y))


        # Process the obtained machine list
        for mach in curr_machine:
            # already here, only update end
            if mach in out_data[0,:]:
                out_data[2,np.where(out_data[0,:] == mach) ] = q
                continue

            # newly seen machine, add to the list 
            out_data[0,mach_counter] = mach
            out_data[1,mach_counter] = q
            out_data[2,mach_counter] = q
            mach_counter += 1

    # Measure the time it takes to go through each machine
    for k, mach in enumerate(out_data[0,:]):
        # if actual machine and not plceholder
        if mach > 0:
            # segments * (pixels / segment) * (meters / pixels) * (seconds / meters)
            out_data[3,k] = ( out_data[2,k] - out_data[1,k] ) * (outer_C / total_pts) * (1/options.ppm) * (1/kmhr2ms(veh_dict['speed_l']))

            # Add vehicle length
            out_data[3,k] = out_data[3,k] + veh_dict['len'] * (1/kmhr2ms(veh_dict['speed_l']))

    # print(out_data)
    # print(out_data)
    # plt.figure()
    # for q in range(0,total_pts+1):
        # plt.plot([in_x_list[q],out_x_list[q]], [in_y_list[q],out_y_list[q]])

    # Now, using the out_data, measure the time_data
    prev_machine_list = [ 0 ]
    prev_start   = 0
    k = 0
    while k < out_data[0,:].size:
        # curr machine & stating index
        mach = out_data[0,k]
        curr_start_idx = out_data[1,k]

        # if we reach end
        if mach == 0:
            total_len = total_pts  # FIX ME: \pm 1??
            for prev_machine in prev_machine_list:
                time_data[int(max_machine+1),int(prev_machine)] = ( total_len - prev_start) * (outer_C / total_pts) * (1/options.ppm) * (1/kmhr2ms(veh_dict['speed_l']))
                ic('Updating : ', int(max_machine+1), int(prev_machine), time_data[int(max_machine+1),int(prev_machine)] )
            break

        # find next machine. Note we might have multiple machines
        ic(prev_machine_list, prev_start)
        next_mach_list = []
        while out_data[1,k] == curr_start_idx:
            next_mach_list.append( out_data[0,k] )

            # Store data

            # time_data[a][b] means arrow from b to a
            # pixels * (meters / pixel) * (seconds / meters)
            for prev_machine in prev_machine_list:
                time_data[int( out_data[0,k] ),int(prev_machine)] = (out_data[1,k] - prev_start) * (outer_C / total_pts) * (1/options.ppm) * (1/kmhr2ms(veh_dict['speed_s']))
                ic('Updating : ', int(out_data[0,k]), int(prev_machine), time_data[int(out_data[0,k]),int(prev_machine)] )

            # increment 
            k = k+1 

        print("\n")
        # Update variables
        prev_machine_list = next_mach_list
        prev_start   = curr_start_idx

    print(time_data)
    return out_data, time_data

def findMachineLeft( mac_array ):
    out_data_list = []
    for lane_cnt in range(0, int_dict['lane_cnt_w_o']):
        # Variables
        # left most position of the lane in meters
        lane_start_pos = int_dict['lane_cnt_w_i'] * int_dict['lane_w'] + lane_cnt * int_dict['lane_w']

        # Left
        dest = 0
        if allowed_dest[0][lane_cnt][dest] == 0:
            # Not allowed
            continue

        # Basic distance to destination lane
        lane_dest_pos = int_dict['lane_cnt_h_o'] * int_dict['lane_w'] + lane_cnt * int_dict['lane_w']

        # minor/major for inner/outer ellipse 
        inner_x_pos = lane_start_pos + 0.5 * ( int_dict['lane_w'] ) - 0.5*veh_dict['width']
        outer_x_pos = lane_start_pos + 0.5 * ( int_dict['lane_w'] ) + 0.5*veh_dict['width']

        inner_y_pos = lane_dest_pos + 0.5 * ( int_dict['lane_w'] ) - 0.5*veh_dict['width']
        outer_y_pos = lane_dest_pos + 0.5 * ( int_dict['lane_w'] ) + 0.5*veh_dict['width']

        out_data_list.append( findMachineLeftLane( mac_array, inner_x_pos * options.ppm , outer_x_pos * options.ppm , inner_y_pos * options.ppm , outer_y_pos * options.ppm ) )


    return out_data_list



    return

# Loop through from a single side and find machine for each lane
def findMachineStraight( mac_array ):
    out_data_list = []
    for lane_cnt in range(0, int_dict['lane_cnt_w_o']):
        # Variables
        # left most position of the lane in meters
        lane_start_pos = int_dict['lane_cnt_w_i'] * int_dict['lane_w'] + lane_cnt * int_dict['lane_w']

        # Straight
        dest = 1
        if allowed_dest[0][lane_cnt][dest] == 0:
            # Not allowed
            continue

        # Go straight
        path_x_start_pos = lane_start_pos + 0.5 * ( int_dict['lane_w'] ) - 0.5*veh_dict['width']
        path_x_end_pos   = lane_start_pos + 0.5 * ( int_dict['lane_w'] ) + 0.5*veh_dict['width']
        path_x_start_cnt = math.floor(path_x_start_pos * options.ppm)
        path_x_end_cnt   = math.ceil(path_x_end_pos * options.ppm)

        print('Lane' + str(lane_cnt))
        out_data_list.append( findMachineStraightLane( mac_array, path_x_start_cnt, path_x_end_cnt ) )

    return out_data_list


# Compute constants from machine list array
#
# direction - 0/1/2 - left/straight/right
def computeConstant(machine_data_list, direction):



    return


# Options
def get_options():
    parser = ArgumentParser()

    parser.add_argument('--ppm', type=int, default=10, help='pixel per meter')
    parser.add_argument('--sampling_time', '-st', type=float, default=0.005, help='sampling for drawing ellipse')
    parser.add_argument('--intersection_xml','-i', default = 'intersection_2.xml')
    parser.add_argument('--vehicle_xml','-v', default = 'vehicle.xml')
    parser.add_argument('--turn_sample','-ts', type = int, default = 100, help = 'Number of sample to pick for dissecting a left turn')
    parser.add_argument('--line_delta','-ld', type = float, default = 0.01, help = 'Delta to pick for line connecting inner and outer ellipse for left turn')

    options = parser.parse_args()
    return options

# Parse XML
def parse_xml():
    #----------------------
    # Parse Intersection Information
    #----------------------
    int_parse = ET.parse( options.intersection_xml).getroot()

    # Make Structure Info into a dict
    int_dict = {}
    for child in int_parse[0]:
        int_dict[child.tag] = int(child.text)

    # Add total width and length
    int_dict['int_w']                     = ( int_dict['lane_cnt_w_o'] + int_dict['lane_cnt_w_i'] )* int_dict['lane_w']     # [m]
    int_dict['int_h']                     = ( int_dict['lane_cnt_h_o'] + int_dict['lane_cnt_h_i'] )* int_dict['lane_w']     # [m]

    # Make Allowed dest into a array
    allowed_dest = np.zeros((4,max( int_dict['lane_cnt_w_o'], int_dict['lane_cnt_h_o']), 3))

    for i, direction in enumerate(int_parse[2]):
        for j, lane in enumerate(direction):
            for k, dest in enumerate(lane):
                allowed_dest[i][j][k] = int(dest.text)

    #----------------------
    # Parse Vehicle Information
    #----------------------
    veh_parse = ET.parse( options.vehicle_xml)

    # Vehicle Data
    veh_parse = ET.parse( options.vehicle_xml).getroot()
    veh_dict = {}
    for child in veh_parse:
        veh_dict[child.tag] = float(child.text)

    return int_dict, allowed_dest, veh_dict


##################
# MAIN
##################

# Input parsing
options = get_options()
print(options)

# XML Parsing
int_dict, allowed_dest, veh_dict = parse_xml()
ic(int_dict, allowed_dest, veh_dict)


# Main Script

# IntersectionMatrix
int_array = np.zeros(( int_dict['int_h']*options.ppm, int_dict['int_w']*options.ppm ), dtype=int )

# Compute collison matrix
int_array = computeCollision()

# Labeled Array denoting each machine
mac_array = np.zeros(( int_dict['int_h']*options.ppm, int_dict['int_w']*options.ppm ), dtype=int )

# compute labelled array
label_mtx_list, mac_array = labelMachine( int_array )


# Plotting
print(int_array)
draw_int( int_array, save = False, title='Overall Intersection Diagram' )
draw_int( mac_array, save = False, title='Labelled Array' )
for idx, val in enumerate(label_mtx_list):
    draw_int( val, save = False, title='Collision level ' + str(idx + 2) )

ic(np.amax(mac_array))

machine_data_straight = findMachineStraight(mac_array)
machine_data_left = findMachineLeft( mac_array )

np.set_printoptions(precision = 4, suppress = True)
ic(machine_data_straight, len(machine_data_straight))
ic(machine_data_left, len(machine_data_left))

# print(machine_data)
plt.show()







